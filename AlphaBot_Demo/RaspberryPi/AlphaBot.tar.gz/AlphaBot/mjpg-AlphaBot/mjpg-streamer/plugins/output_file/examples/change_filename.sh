#!/bin/bash

################################################################################
#
# If you do not like the default filename it can be changed easily
#
# The ringbuffer feature will not work if the filename is changed!
#
################################################################################

mv "$1" "/tmp/picture.jpg"
